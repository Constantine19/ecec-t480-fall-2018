function b = tpose(a)
% multiplies two matrices
    b = a.';
end