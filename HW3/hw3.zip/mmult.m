function c = mmult(a, b)
% multiplies two matrices
    c = a * b;
end