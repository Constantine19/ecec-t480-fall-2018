function [l, u] = lu_decomp(A)

[l, u] = lu(A);

end

