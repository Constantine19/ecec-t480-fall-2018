function x = matinv(A)

x = inv(A);
end

